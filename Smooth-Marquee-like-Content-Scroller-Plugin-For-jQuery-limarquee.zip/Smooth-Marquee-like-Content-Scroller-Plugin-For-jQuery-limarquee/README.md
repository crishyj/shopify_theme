# jquery.limarquee
github repository http://masscode.ru/index.php/k2/item/44-limarquee
